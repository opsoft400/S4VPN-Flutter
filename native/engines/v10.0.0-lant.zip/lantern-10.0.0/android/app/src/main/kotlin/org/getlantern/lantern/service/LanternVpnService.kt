package org.getlantern.lantern.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import lantern.io.libbox.Notification
import lantern.io.libbox.StringIterator
import lantern.io.libbox.TunOptions
import lantern.io.mobile.Mobile
import lantern.io.utils.Opts
import org.getlantern.lantern.BuildConfig
import org.getlantern.lantern.MainActivity
import org.getlantern.lantern.constant.VPNStatus
import org.getlantern.lantern.notification.NotificationHelper
import org.getlantern.lantern.service.LanternVpnService.Companion.ACTION_STOP_VPN
import org.getlantern.lantern.utils.AppLogger
import org.getlantern.lantern.utils.DeviceUtil
import org.getlantern.lantern.utils.FlutterEventListener
import org.getlantern.lantern.utils.VpnStatusManager
import org.getlantern.lantern.utils.getRadianceEnv
import org.getlantern.lantern.utils.initConfigDir
import org.getlantern.lantern.utils.isTelemetryEnabled
import org.getlantern.lantern.utils.logDir
import org.getlantern.lantern.utils.toIpPrefix

/**
 * Service to manage VPN connection and Radiance setup, and other VPN-related tasks.
 * Since this service is used for the quick tile,
 * it should not include any logic that needs to be connected with any activity.
 * everything should be done in independent
 */
class LanternVpnService :
    VpnService(),
    PlatformInterfaceWrapper {
    companion object {
        private const val TAG = "LanternVpnService"
        private const val sessionName = "LanternVpn"
        const val ACTION_START_RADIANCE = "com.getlantern.START_RADIANCE"
        const val ACTION_START_VPN = "org.getlantern.START_VPN"
        const val ACTION_CONNECT_TO_SERVER = "org.getlantern.CONNECT_TO_SERVER"
        const val ACTION_STOP_VPN = "org.getlantern.START_STOP"
        const val ACTION_TILE_START = "org.getlantern.TILE_START"

        private const val UPGRADE_RESET_PREFS = "vpn_upgrade_reset"
        private const val LAST_RESET_APK_UPDATE_TIME = "last_reset_apk_update_time"
        private const val UPGRADE_RESET_SETTLE_MS = 250L

        // Hard ceiling on how long Mobile.startVPN / connectToServer can block.
        // Radiance + sing-box + TUN establish usually finishes in under 15 s;
        // anything above 60 s means the Go side has deadlocked (see Freshdesk
        // #173507, where /service/start hung and the UI appeared frozen until
        // a phone reboot). Without this timeout the coroutine could wait forever.
        private const val VPN_START_TIMEOUT_MS = 60_000L

        // Single-flight gate: when we time out the connect() call, we detach
        // the coroutine rather than waiting for the JNI call to honor
        // cancellation (it doesn't). The orphan keeps a Dispatchers.IO thread
        // pinned until Go eventually returns. To prevent multiple rapid
        // retries from accumulating orphans and pressuring the IO pool, reject
        // new connect attempts while a previous one is still in flight. The
        // flag clears when the orphan's coroutine actually completes.
        private val connectInFlight = AtomicBoolean(false)

        private sealed class RadianceState {
            data object Initializing : RadianceState()
            data object Ready : RadianceState()
            data class Failed(val cause: Throwable) : RadianceState()
        }

        private val radianceState = MutableStateFlow<RadianceState>(RadianceState.Initializing)
        private val radianceSetupMutex = Mutex()

        suspend fun awaitRadianceReady() {
            if (Mobile.isRadianceConnected()) return
            when (val state = radianceState.first { it !is RadianceState.Initializing }) {
                RadianceState.Ready -> check(Mobile.isRadianceConnected()) {
                    "Radiance setup completed but the core is unavailable"
                }
                is RadianceState.Failed -> throw state.cause
                RadianceState.Initializing -> error("Radiance is still initializing")
            }
        }

        lateinit var instance: LanternVpnService

        // Process-lifetime scope for teardown that must run off the main thread
        // but outlive the service instance. Mobile.stopVPN() is a blocking JNI
        // call; running it on the main thread in onDestroy ANRs during service
        // teardown (getlantern/engineering#3563). serviceScope is cancelled in
        // onDestroy's finally, so teardown can't live there — this scope is
        // never cancelled.
        private val teardownScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    }

    private val notificationHelper = NotificationHelper()

    private val flutterEventListener = FlutterEventListener()

    private var mInterface: ParcelFileDescriptor? = null

    /**
     * Safely close the TUN interface file descriptor.
     * Synchronized to prevent double-close from concurrent callers
     * (onDestroy, postServiceClose, doStopVPN can all race).
     */
    @Synchronized
    private fun closeTunInterface() {
        try {
            mInterface?.close()
        } catch (e: Exception) {
            AppLogger.e(TAG, "Error closing TUN interface", e)
        } finally {
            mInterface = null
        }
    }

    // Create a CoroutineScope tied to the service's lifecycle.
    //
    // SupervisorJob keeps one child's failure from cancelling its siblings, but it does
    // not handle the exception: without a CoroutineExceptionHandler an uncaught throw in
    // any launch{} below reaches the thread's default handler and takes the process down
    // with no Kotlin log and no Go crash file, which reads as a silent death. The handler
    // makes that case diagnosable and reports it to the UI like any other VPN error.
    private val serviceScope =
        CoroutineScope(
            Dispatchers.IO + SupervisorJob() +
                CoroutineExceptionHandler { _, e ->
                    AppLogger.e(TAG, "Uncaught exception in service coroutine", e)
                    VpnStatusManager.postVPNError(
                        errorCode = "service_coroutine_uncaught",
                        errorMessage = "Unexpected VPN service error",
                        error = e,
                    )
                },
        )

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int,
    ): Int {
        instance = this
        val action = intent?.action ?: return START_NOT_STICKY
        if (!MainActivity.receiverRegistered) {
            VpnStatusManager.registerVPNStatusReceiver()
            MainActivity.receiverRegistered = true
        }

        AppLogger.d(TAG, "Received action: $action")

        // Drop duplicate connect commands at the door: taps racing the
        // status round-trip otherwise spawn concurrent attempts. Safe to
        // return without startForeground — the in-flight attempt has
        // already put the service in the foreground.
        val isConnectAction = action == ACTION_START_VPN ||
            action == ACTION_CONNECT_TO_SERVER ||
            action == ACTION_TILE_START
        if (isConnectAction && connectInFlight.get()) {
            AppLogger.i(TAG, "Ignoring $action: connect already in flight")
            return START_STICKY
        }

        return when (action) {
            ACTION_START_RADIANCE -> {
                serviceScope.launch {
                    startRadiance()
                }
                AppLogger.d(TAG, "Started Radiance")
                START_NOT_STICKY
            }

            ACTION_START_VPN -> {
                serviceScope.launch {
                    startVPN()
                }
                AppLogger.d(TAG, "Started VPN")
                START_STICKY
            }

            ACTION_CONNECT_TO_SERVER -> {
                serviceScope.launch {
                    connectToServer(intent.getStringExtra("tag") ?: "")
                }
                AppLogger.d(TAG, "Connecting to server")
                START_STICKY
            }

            ACTION_TILE_START -> {
                serviceScope.launch {
                    if (!Mobile.isRadianceConnected()) {
                        startRadiance()
                    }
                    startVPN()
                    notificationHelper.showVPNConnectedNotification(this@LanternVpnService)
                }
                AppLogger.d(TAG, "Tile triggered VPN start")
                START_STICKY
            }

            ACTION_STOP_VPN -> {
                AppLogger.d(TAG, "Received ACTION_STOP_VPN")
                serviceScope.launch {
                    performStopVPN()
                }
                START_NOT_STICKY
            }

            else -> START_NOT_STICKY
        }
    }

    override fun onDestroy() {
        try {
            AppLogger.d(TAG, "destroying LanternVpnService")
            // Only the TUN fd close stays synchronous on the main thread — it's
            // cheap and the OS should release the interface promptly.
            closeTunInterface()

            // Everything else runs OFF the main thread. Mobile.stopVPN() is a
            // blocking JNI call (tunnel/connection close) — running it on the
            // main thread here ANRs during service teardown and contends with any
            // in-flight performStopVPN (getlantern/engineering#3563). teardownScope
            // is process-lifetime, so this survives the serviceScope.cancel()
            // below and still completes, keeping the next process launch clean.
            // Mobile.stopVPN() is a no-op when c.tunnel is already nil, so a
            // double-call from the stop path is harmless. Closed unconditionally
            // when radiance is up: any non-Connected state (Restarting,
            // Connecting, Disconnecting, Error) still has a non-nil c.tunnel.
            // The notification/tile/receiver cleanup runs AFTER stopVPN so the UI
            // reflects the stopped state and the status receiver stays registered
            // through teardown. serviceCleanUp() unregisters via the application
            // context (not the service), so running it after super.onDestroy() is safe.
            teardownScope.launch {
                runCatching {
                    if (Mobile.isRadianceConnected()) {
                        Mobile.stopVPN()
                        AppLogger.d(TAG, "stopVPN completed during destroy")
                    } else {
                        AppLogger.d(TAG, "Skipping stopVPN — Radiance IPC not running")
                    }
                }.onFailure { e -> AppLogger.e(TAG, "Mobile.stopVPN() failed during destroy", e) }

                runCatching { DefaultNetworkMonitor.stop() }
                    .onFailure { e -> AppLogger.e(TAG, "DefaultNetworkMonitor.stop() failed during destroy", e) }

                notificationHelper.stopVPNConnectedNotification(this@LanternVpnService)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    QuickTileService.triggerUpdateTileState(this@LanternVpnService, false)
                }
                serviceCleanUp()
            }
        } finally {
            serviceScope.cancel()
            super.onDestroy()
        }
    }

    override fun autoDetectInterfaceControl(p0: Int) {
        protect(p0)
    }

    override fun openTun(tunOptions: TunOptions): Int {
        val vpnBuilder = createVPNBuilder(tunOptions)
        // Android normally tears the previous TUN down when a new VPN is
        // established, but explicitly dropping our fd first prevents a stale
        // descriptor from surviving restarts or app-upgrade recovery.
        closeTunInterface()
        val pfd =
            vpnBuilder.establish()
                ?: error("android: the application is not prepared or is revoked")
        mInterface = pfd
        return pfd.fd
    }

    override fun postServiceClose() {
        AppLogger.i(TAG, "postServiceClose called")
        closeTunInterface()
    }

    override fun restartService() {
        AppLogger.i(TAG, "restartService called")
        // Radiance's Restart() sets the tunnel status to Restarting, then
        // calls us synchronously and treats a successful return as "restart
        // complete." If we fire-and-forget via serviceScope.launch and return,
        // radiance thinks it succeeded but the tunnel is still in Restarting —
        // and if the Android service is torn down (onDestroy, process
        // pressure) before the launched coroutine completes, the tunnel
        // wedges in Restarting forever. Every subsequent Connect fails with
        // "tunnel is currently Restarting" (getlantern/engineering#3297
        // issues 1-3, Freshdesk #173681).
        //
        // Block until stopVPNTunnel + startVPN finish so the return actually
        // reflects the state radiance observes. c.mu is released on the Go
        // side before RestartService is invoked, so synchronous callbacks
        // into Mobile.* from this thread don't deadlock.
        runBlocking(Dispatchers.IO) {
            stopVPNTunnel()
            startVPN()
            // launchVPN (wrapping startVPN) catches failures via
            // runCatching { ... }.onFailure { ... } and returns normally,
            // so a nil return from startVPN doesn't mean the restart
            // succeeded. Verify the postcondition on the Go side and
            // throw if it's not met — the exception propagates through
            // runBlocking → restartService → radiance's Restart() as a
            // non-nil error, which is what tells the caller the restart
            // actually failed and the tunnel needs healing rather than
            // wedging forever in Restarting.
            if (!Mobile.isVPNConnected()) {
                val msg = "restartService failed: VPN not connected after stopVPNTunnel + startVPN"
                AppLogger.e(TAG, msg)
                throw IllegalStateException(msg)
            }
        }
        AppLogger.i(TAG, "restartService completed")
    }

    override fun sendNotification(notification: Notification?) {
        notificationHelper.sendNotification(notification)
    }

    override fun systemCertificates(): StringIterator {
        //return empty iterator as we are not using system certificates
        return object : StringIterator {
            override fun hasNext(): Boolean = false
            override fun len(): Int {
                return 0
            }

            override fun next(): String = ""
        }

    }

    private suspend fun startRadiance() {
        try {
            withContext(Dispatchers.IO) {
                setupRadiance()
            }
            AppLogger.d(TAG, "Radiance setup completed")
        } catch (e: Exception) {
            AppLogger.e(TAG, "Error in Radiance setup", e)
        }
    }

    private suspend fun setupRadiance() {
        radianceSetupMutex.withLock {
            if (Mobile.isRadianceConnected()) {
                radianceState.value = RadianceState.Ready
                return@withLock
            }

            radianceState.value = RadianceState.Initializing
            try {
                Mobile.startIPCServer(this@LanternVpnService, opts())
                Mobile.setupRadiance(opts(), flutterEventListener)
                radianceState.value = RadianceState.Ready
            } catch (e: Exception) {
                radianceState.value = RadianceState.Failed(e)
                throw e
            }
        }
    }

     suspend fun startVPN() = launchVPN(
        errorCode = "start_vpn",
        cleanUpOnFailure = true,
    ) {
        Mobile.startVPN()
        AppLogger.d(TAG, "VPN service started")
    }

    suspend fun connectToServer(
        tag: String,
    ) = launchVPN(
        errorCode = "connect_to_server",
        cleanUpOnFailure = false,
    ) {
        Mobile.connectToServer( tag)
        AppLogger.d(TAG, "Connected to server")
    }

    /**
     * Common flow for starting/connecting VPN: checks permission, shows foreground
     * notification, starts network monitor, runs [connect], then updates UI on success.
     */
    private suspend fun launchVPN(
        errorCode: String,
        cleanUpOnFailure: Boolean,
        connect: suspend () -> Unit,
    ) = withContext(Dispatchers.IO) {
        if (prepare(this@LanternVpnService) != null) {
            VpnStatusManager.postVPNStatus(VPNStatus.MissingPermission)
            return@withContext
        }
        runCatching {
            // Show foreground notification immediately — required by the OS as soon as
            // VPN service starts, replaced by the connected notification on success.
            // This is startForeground() underneath, which the OS can refuse over
            // foreground-service type, permission, or vendor policy. Inside the block
            // so a refusal takes this operation's own failure path — errorCode-tagged
            // reporting, network-monitor teardown, and serviceCleanUp when the caller
            // asked for it — rather than the service-wide handler, which only logs and
            // posts a generic error.
            notificationHelper.showStartingVPNConnectedNotification(this@LanternVpnService)
            // Radiance is pre-warmed via ACTION_START_RADIANCE, but as a background
            // service it may have been killed by the OS before setup completed.
            // Re-run setup here under the foreground notification so it is guaranteed
            // to finish before we attempt to start the VPN tunnel.
            if (!Mobile.isRadianceConnected()) {
                AppLogger.d(TAG, "Radiance not ready, setting up before VPN start")
                setupRadiance()
            }
            resetVpnAfterAppUpgradeIfNeeded()
            DefaultNetworkMonitor.setNetworkChangeCallback { updateUnderlyingNetworks() }
            DefaultNetworkMonitor.start()
            // Tell Android which physical network underlies our VPN so that
            // ConnectivityManager.getAllNetworks() returns it alongside the VPN.
            // Without this, some Android 10+ devices report only the VPN network,
            // causing sing-box to see no physical interface and blocking all traffic.
            updateUnderlyingNetworks()
            // Bound the Mobile.startVPN / connectToServer call with a wall-clock
            // timeout. These are blocking JNI calls with no suspension points,
            // so withTimeout around a direct invocation wouldn't fire — we run
            // the call in async() and await it so withTimeout has a real
            // cancellation point.
            //
            // Run it in a DETACHED CoroutineScope (not a structured
            // coroutineScope { } / the enclosing withContext), because on
            // timeout structured concurrency would cancel the deferred and
            // then wait for it to complete — and since the JNI call doesn't
            // honor cooperative cancellation, that wait is exactly the hang
            // we're trying to prevent. A detached SupervisorJob scope lets
            // us stop awaiting without joining; the orphan coroutine keeps
            // running until Go returns (or the process exits), but the
            // caller is unblocked and the UI surfaces a clear error instead
            // of a frozen button only a phone reboot can clear
            // (Freshdesk #173507).
            //
            // Reject concurrent attempts with connectInFlight so repeated
            // retries while a previous call is stuck in JNI don't accumulate
            // orphan coroutines on Dispatchers.IO. Clear the flag from the
            // Deferred completion path so early cancellation before the async
            // body starts can't wedge future attempts.
            // Duplicate attempt (e.g. double-tap): drop it — the in-flight
            // attempt reports its own result.
            if (!connectInFlight.compareAndSet(false, true)) {
                AppLogger.i(TAG, "VPN operation ($errorCode) ignored: previous connect attempt still in flight")
                return@runCatching
            }
            val connectScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            val deferred = connectScope.async { connect() }
            deferred.invokeOnCompletion {
                connectInFlight.set(false)
            }
            try {
                withTimeout(VPN_START_TIMEOUT_MS) { deferred.await() }
            } catch (e: TimeoutCancellationException) {
                deferred.cancel()
                throw e
            } finally {
                connectScope.cancel()
            }
            VpnStatusManager.postVPNStatus(VPNStatus.Connected)
            notificationHelper.showVPNConnectedNotification(this@LanternVpnService)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                QuickTileService.triggerUpdateTileState(this@LanternVpnService, true)
            }
        }.onFailure { e ->
            val timedOut = e is TimeoutCancellationException
            if (timedOut) {
                AppLogger.e(TAG, "VPN operation ($errorCode) timed out after ${VPN_START_TIMEOUT_MS}ms — Go side likely deadlocked", e)
            } else {
                AppLogger.e(TAG, "Error in VPN operation ($errorCode)", e)
            }
            // Clear the network change callback to avoid leaking this service
            // instance through the static DefaultNetworkMonitor singleton.
            DefaultNetworkMonitor.setNetworkChangeCallback(null)
            runCatching { runBlocking { DefaultNetworkMonitor.stop() } }
                .onFailure { stopErr -> AppLogger.e(TAG, "DefaultNetworkMonitor.stop() failed in error path", stopErr) }
            VpnStatusManager.postVPNError(
                errorCode = if (timedOut) "${errorCode}_timeout" else errorCode,
                errorMessage = if (timedOut) "VPN operation timed out" else "Error in VPN operation",
                error = e,
            )
            // Don't unregister the status receiver while a tunnel may still
            // need it: skip cleanup when the tunnel is up, when the bridge
            // can't tell us (unknown counts as connected), or while a timed-out
            // connect is still running detached and may yet bring the tunnel up.
            val mayBeConnected = runCatching { Mobile.isVPNConnected() }.getOrDefault(true)
            if (cleanUpOnFailure && !mayBeConnected && !connectInFlight.get()) serviceCleanUp()
        }
    }

    private suspend fun resetVpnAfterAppUpgradeIfNeeded() {
        if (!consumeUpgradeResetMarker()) return

        // An APK update kills the old process, but the Android VPN profile and
        // app-private native state persist across the upgrade. Reset once on the
        // first tunnel start after the new process comes up.
        AppLogger.i(TAG, "App APK updated; resetting VPN state before first tunnel start")
        stopVPNTunnel()
        VpnStatusManager.postVPNStatus(VPNStatus.Disconnected)
        delay(UPGRADE_RESET_SETTLE_MS)
    }

    private fun consumeUpgradeResetMarker(): Boolean {
        val packageInfo = currentPackageInfo()
        val currentApkUpdateTime = packageInfo.lastUpdateTime
        val prefs = getSharedPreferences(UPGRADE_RESET_PREFS, Context.MODE_PRIVATE)
        val lastResetApkUpdateTime = prefs.getLong(LAST_RESET_APK_UPDATE_TIME, Long.MIN_VALUE)
        if (lastResetApkUpdateTime == currentApkUpdateTime) {
            return false
        }

        prefs.edit().putLong(LAST_RESET_APK_UPDATE_TIME, currentApkUpdateTime).apply()
        if (packageInfo.lastUpdateTime <= packageInfo.firstInstallTime) {
            AppLogger.d(TAG, "Recording initial APK install for VPN upgrade reset")
            return false
        }

        AppLogger.i(
            TAG,
            "VPN upgrade reset needed: lastResetApkUpdateTime=$lastResetApkUpdateTime currentApkUpdateTime=$currentApkUpdateTime versionCode=${packageVersionCode(packageInfo)}",
        )
        return true
    }

    private fun currentPackageInfo(): PackageInfo {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(
                packageName,
                PackageManager.PackageInfoFlags.of(0),
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0)
        }
    }

    private fun packageVersionCode(info: PackageInfo): Long {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }
    }

    fun doStopVPN() {
        AppLogger.d(TAG, "doStopVPN")
        serviceScope.launch {
            performStopVPN()
        }
    }

    /**
     * Tears down only the VPN tunnel without touching the broadcast receiver
     * or service lifecycle. Used by [restartService] so the receiver stays
     * registered and the service can still receive stop commands after restart.
     */
    private suspend fun stopVPNTunnel() {
        try {
            closeTunInterface()
            // Unconditionally call Mobile.stopVPN() as long as radiance is up.
            // The old isVPNConnected() guard looked at status == Connected,
            // which is wrong during a restart: radiance sets the tunnel to
            // Restarting before calling back into the platform, so the check
            // would skip stopVPN and leave the tunnel wedged in Restarting
            // (getlantern/engineering#3297). Mobile.stopVPN() itself is a
            // no-op when c.tunnel is nil, so the guard is unnecessary.
            runCatching {
                if (!Mobile.isRadianceConnected()) {
                    AppLogger.d(TAG, "Radiance IPC not running, skipping stopVPN")
                    return@runCatching
                }
                Mobile.stopVPN()
            }
                .onFailure { e -> AppLogger.e(TAG, "Mobile.stopVPN() failed", e) }

            runCatching { DefaultNetworkMonitor.stop() }
                .onFailure { e -> AppLogger.e(TAG, "DefaultNetworkMonitor.stop() failed", e) }
        } catch (e: Exception) {
            AppLogger.e(TAG, "Error tearing down VPN tunnel", e)
        }
    }

    /**
     * Full VPN stop: tears down the tunnel, updates UI/notifications/tile,
     * posts disconnected status, and cleans up the service (unregisters receiver).
     * Used by [doStopVPN] and [ACTION_STOP_VPN].
     */
    private suspend fun performStopVPN() {
        VpnStatusManager.postVPNStatus(VPNStatus.Disconnecting)
        try {
            stopVPNTunnel()
            notificationHelper.stopVPNConnectedNotification(this@LanternVpnService)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                QuickTileService.triggerUpdateTileState(this@LanternVpnService, false)
            }
            VpnStatusManager.postVPNStatus(VPNStatus.Disconnected)
            serviceCleanUp()
        } catch (e: Exception) {
            AppLogger.e(TAG, "Error stopping VPN service", e)
            VpnStatusManager.postVPNError(
                error = e,
                errorCode = "stop_vpn",
                errorMessage = "Error stopping VPN service",
            )
        }
    }

    /**
     * Informs the OS which physical networks underlie our VPN. This ensures
     * ConnectivityManager.getAllNetworks() returns the physical network alongside
     * the VPN, which sing-box needs to bind outbound connections to the real
     * interface. Without this, some devices (notably Android 10) only see the VPN
     * network and sing-box's direct outbound fails with "no available network interface".
     */
    private fun updateUnderlyingNetworks() {
        val network = DefaultNetworkMonitor.defaultNetwork
        if (network != null) {
            setUnderlyingNetworks(arrayOf(network))
        } else {
            // null tells Android to use the system default
            setUnderlyingNetworks(null)
        }
    }

    private fun serviceCleanUp() {
        AppLogger.d(TAG, "Cleaning up service")
        VpnStatusManager.unregisterVPNStatusReceiver(this)
        MainActivity.receiverRegistered = false
    }

    private fun createVPNBuilder(options: TunOptions): Builder {
        val builder = Builder().setSession(sessionName).setMtu(options.mtu)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }
        val inet4Address = options.inet4Address
        while (inet4Address.hasNext()) {
            val address = inet4Address.next()
            builder.addAddress(address.address(), address.prefix())
        }

        val inet6Address = options.inet6Address
        while (inet6Address.hasNext()) {
            val address = inet6Address.next()
            builder.addAddress(address.address(), address.prefix())
        }

        // Disallow traffic from our own app to the VPN.
        builder.addDisallowedApplication(BuildConfig.APPLICATION_ID)

        if (options.autoRoute) {
            builder.addDnsServer(options.dnsServerAddress.value)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val inet4RouteAddress = options.inet4RouteAddress
                if (inet4RouteAddress.hasNext()) {
                    while (inet4RouteAddress.hasNext()) {
                        builder.addRoute(inet4RouteAddress.next().toIpPrefix())
                    }
                } else if (options.inet4Address.hasNext()) {
                    builder.addRoute("0.0.0.0", 0)
                }

                val inet6RouteAddress = options.inet6RouteAddress
                if (inet6RouteAddress.hasNext()) {
                    while (inet6RouteAddress.hasNext()) {
                        builder.addRoute(inet6RouteAddress.next().toIpPrefix())
                    }
                } else if (options.inet6Address.hasNext()) {
                    builder.addRoute("::", 0)
                }

                val inet4RouteExcludeAddress = options.inet4RouteExcludeAddress
                while (inet4RouteExcludeAddress.hasNext()) {
                    builder.excludeRoute(inet4RouteExcludeAddress.next().toIpPrefix())
                }

                val inet6RouteExcludeAddress = options.inet6RouteExcludeAddress
                while (inet6RouteExcludeAddress.hasNext()) {
                    builder.excludeRoute(inet6RouteExcludeAddress.next().toIpPrefix())
                }
            } else {
                val inet4RouteAddress = options.inet4RouteRange
                if (inet4RouteAddress.hasNext()) {
                    while (inet4RouteAddress.hasNext()) {
                        val address = inet4RouteAddress.next()
                        builder.addRoute(address.address(), address.prefix())
                    }
                }

                val inet6RouteAddress = options.inet6RouteRange
                if (inet6RouteAddress.hasNext()) {
                    while (inet6RouteAddress.hasNext()) {
                        val address = inet6RouteAddress.next()
                        builder.addRoute(address.address(), address.prefix())
                    }
                }
            }
        }
        return builder
    }

    fun opts(): Opts {
        val opts =
            Opts().apply {
                dataDir = initConfigDir()
                logDir = logDir()
                logLevel = "trace"
                deviceid = DeviceUtil.deviceId()
                appVersion = BuildConfig.VERSION_NAME
                locale = DeviceUtil.getLanguageCode(this@LanternVpnService)
                telemetryConsent = isTelemetryEnabled()
                env = getRadianceEnv()
                platform = this@LanternVpnService
            }
        return opts
    }
}
