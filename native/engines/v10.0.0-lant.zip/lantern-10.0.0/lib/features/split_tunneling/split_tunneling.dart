import 'package:auto_route/auto_route.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lantern/core/common/app_text_styles.dart';
import 'package:lantern/core/common/common.dart';
import 'package:lantern/core/models/app_data.dart';
import 'package:lantern/core/models/website.dart';
import 'package:lantern/core/widgets/split_tunneling_tile.dart';
import 'package:lantern/core/widgets/switch_button.dart';
import 'package:lantern/features/home/provider/radiance_settings_providers.dart';
import 'package:lantern/features/split_tunneling/provider/apps_notifier.dart';
import 'package:lantern/features/split_tunneling/provider/website_notifier.dart';

@RoutePage(name: 'SplitTunneling')
class SplitTunneling extends HookConsumerWidget {
  const SplitTunneling({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final textTheme = Theme.of(context).textTheme;
    final splitTunnelingEnabled = ref.watch(
      radianceSettingsProvider.select((s) => s.splitTunneling),
    );

    final enabledApps =
        (ref.watch(splitTunnelingAppsProvider).value ?? const <AppData>{})
            .toList(growable: false);

    final enabledWebsites =
        (ref.watch(splitTunnelingWebsitesProvider).value ?? const <Website>{})
            .toList(growable: false);

    void toggleSplitTunneling() {
      ref
          .read(radianceSettingsProvider.notifier)
          .setSplitTunneling(!splitTunnelingEnabled);
    }

    return BaseScreen(
      title: 'split_tunneling'.i18n,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(height: defaultSize),
          AppCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                AppTile(
                  label: 'split_tunneling'.i18n,
                  tileTextStyle: AppTextStyles.bodyMedium.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: context.textPrimary,
                  ),
                  subtitle: AutoSizeText(
                    'add_apps_websites_bypass_vpn'.i18n,
                    minFontSize: 10,
                    maxLines: 2,
                    maxFontSize: 12,
                    style: textTheme.labelMedium!.copyWith(
                      color: context.textTertiary,
                      letterSpacing: 0.0,
                    ),
                  ),
                  onPressed: toggleSplitTunneling,
                  trailing: SwitchButton(
                    value: splitTunnelingEnabled,
                    onChanged: (bool? value) {
                      ref
                          .read(radianceSettingsProvider.notifier)
                          .setSplitTunneling(value ?? false);
                    },
                    activeColor: AppColors.green5,
                  ),
                ),
                if (splitTunnelingEnabled) ...{
                  DividerSpace(),
                  SplitTunnelingTile(
                    icon: AppImagePaths.keypad,
                    label: 'apps'.i18n,
                    actionText: '${enabledApps.length} Added',
                    onPressed: () => appRouter.push(AppsSplitTunneling()),
                  ),
                  DividerSpace(),
                  SplitTunnelingTile(
                    icon: AppImagePaths.world,
                    label: 'websites'.i18n,
                    actionText: '${enabledWebsites.length} Added',
                    onPressed: () => appRouter.push(WebsiteSplitTunneling()),
                  ),
                },
              ],
            ),
          ),
        ],
      ),
    );
  }
}
