import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lantern/core/common/common.dart';
import 'package:lantern/core/widgets/email_tag.dart';
import 'package:lantern/core/widgets/password_criteria.dart';
import 'package:lantern/core/keys/app_keys.dart';
import 'package:lantern/features/auth/provider/auth_notifier.dart';
import 'package:lantern/features/home/provider/app_setting_notifier.dart';
import 'package:lantern/features/plans/provider/payment_notifier.dart';

@RoutePage(name: 'CreatePassword')
class CreatePassword extends HookConsumerWidget {
  final String email;
  final String code;
  final AuthFlow authFlow;

  const CreatePassword({
    super.key,
    required this.email,
    required this.authFlow,
    required this.code,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final passwordTextController = useTextEditingController();
    final obscureText = useState(true);
    final isValidPassword = useState(false);
    return EnterKeyShortcut(
      onEnter: () {
        if (passwordTextController.text.isPasswordValid()) {
          onContinue(ref, passwordTextController.text, context);
        }
      },
      child: BaseScreen(
        title: 'create_password'.i18n,
        body: SingleChildScrollView(
          child: AutofillGroup(
            child: Column(
              children: <Widget>[
                SizedBox(height: defaultSize),
                EmailTag(email: email),
                SizedBox(height: defaultSize),
                AppTextField(
                  fieldKey: AuthKeys.createPasswordField,
                  controller: passwordTextController,
                  hintText: '',
                  prefixIcon: AppImagePaths.lock,
                  label: "create_password".i18n,
                  keyboardType: TextInputType.visiblePassword,
                  textInputAction: TextInputAction.done,
                  autofillHints: const [AutofillHints.newPassword],
                  enableSuggestions: false,
                  autocorrect: false,
                  suffixIcon: _buildSuffix(obscureText, context),
                  obscureText: obscureText.value,
                  onSubmitted: (_) {
                    if (passwordTextController.text.isPasswordValid()) {
                      onContinue(ref, passwordTextController.text, context);
                    }
                  },
                  onChanged: (value) {
                    isValidPassword.value = value.isPasswordValid();
                  },
                ),
                SizedBox(height: 32),
                PrimaryButton(
                  key: AuthKeys.createPasswordContinueButton,
                  label: 'continue'.i18n,
                  isTaller: true,
                  enabled: passwordTextController.text.isPasswordValid(),
                  onPressed: () =>
                      onContinue(ref, passwordTextController.text, context),
                ),
                SizedBox(height: 32.0),
                PasswordCriteriaWidget(
                  textEditingController: passwordTextController,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSuffix(ValueNotifier<bool> obscureText, BuildContext context) {
    return AppImage(
      color: context.textPromoIcon,
      path: obscureText.value ? AppImagePaths.eyeHide : AppImagePaths.eye,
      onPressed: () {
        obscureText.value = !obscureText.value;
      },
    );
  }

  Future<void> onContinue(
    WidgetRef ref,
    String password,
    BuildContext context,
  ) async {
    hideKeyboard();
    context.showLoadingDialog();
    final result = await ref
        .read(authProvider.notifier)
        .completeRecoveryByEmail(email, password, code);

    result.fold(
      (failure) {
        context.hideLoadingDialog();
        appLogger.error('Failed to create password: ${failure.error}');
        context.showSnackBarError(failure.localizedErrorMessage);
      },
      (success) {
        context.hideLoadingDialog();
        TextInput.finishAutofillContext(shouldSave: true);
        appLogger.info('Password created successfully');
        ref.read(appSettingProvider.notifier).setUserLoggedIn(true);
        // Signup completed: release any payment-in-flight flag set by an IAP
        // (or other payment) flow that routed the user here, so future
        // unrelated signup back-presses are not misprotected.
        ref.read(paymentSessionProvider.notifier).clearRedirect();
        resolveRoutes(context, ref);
      },
    );
  }

  Future<void> resolveRoutes(BuildContext context, WidgetRef ref) async {
    if (isStoreVersion()) {
      //We need call get user details here by then user has made payment
      context.showLoadingDialog();
      await checkUserAccountStatus(ref, context);
      if (!context.mounted) return;
      context.hideLoadingDialog();
    }
    if (!context.mounted) return;
    AppDialog.showLanternProDialog(
      context: context,
      onPressed: () {
        appRouter.popUntilRoot();
      },
    );
  }
}
