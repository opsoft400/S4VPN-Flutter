import 'package:fpdart/fpdart.dart';
import 'package:lantern/core/common/common.dart';
import 'package:lantern/core/extensions/user_data.dart';
import 'package:lantern/core/models/user.dart';
import 'package:lantern/features/home/provider/app_setting_notifier.dart';
import 'package:lantern/features/plans/provider/payment_notifier.dart';
import 'package:lantern/features/plans/provider/referral_notifier.dart';
import 'package:lantern/features/vpn/provider/server_location_notifier.dart';
import 'package:lantern/lantern/lantern_service_notifier.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'home_notifier.g.dart';

@Riverpod(keepAlive: true)
class HomeNotifier extends _$HomeNotifier {
  @override
  Future<UserResponseModel> build() async {
    /// Check if user data is stored locally
    /// If yes, load it first to avoid delay in UI
    final service = ref.read(lanternServiceProvider);
    await service.waitForRadiance();
    final result = await service.getUserData();
    return result.fold(
      (failure) {
        appLogger.error('Error getting user data: ${failure.error}');
        throw Exception('Failed to get user data');
      },
      (userData) {
        appLogger.debug('Loaded cached user data');
        _applyUserData(userData);
        return userData;
      },
    );
  }

  /// Fetches the latest user data from the server
  Future<void> fetchUserData() async {
    final result = await ref.read(lanternServiceProvider).fetchUserData();
    result.fold(
      (failure) {
        appLogger.error('Error fetching user data: ${failure.error}');
      },
      (userData) {
        appLogger.debug('Fetched user data from server');
        _applyUserData(userData);
      },
    );
  }

  /// Re-reads cached user data from Go without a loading state.
  Future<void> reloadUserData() async {
    // Let a pending build() finish first so its older read cannot overwrite
    // the fresher data.
    try {
      await future;
    } catch (_) {}
    if (!ref.mounted) return;
    final result = await ref.read(lanternServiceProvider).getUserData();
    if (!ref.mounted) return;
    result.fold(
      (failure) {
        appLogger.error('Error reloading user data: ${failure.error}');
      },
      (userData) {
        appLogger.debug('Reloaded cached user data');
        _applyUserData(userData);
      },
    );
  }

  /// Force refresh from Go
  Future<void> refreshUser() async {
    state = const AsyncValue.loading();

    final result = await ref.read(lanternServiceProvider).getUserData();
    result.fold(
      (failure) {
        appLogger.error('Error refreshing user data: ${failure.error}');
        state = AsyncValue.error(failure, StackTrace.current);
      },
      (userData) {
        appLogger.debug('Refreshed cached user data');
        _applyUserData(userData);
      },
    );
  }

  /// Updates the user data in state and local storage.
  /// notifies UI about changes.
  void updateUserData(UserResponseModel userData) {
    _applyUserData(userData);
  }

  void _applyUserData(UserResponseModel userData) {
    state = AsyncValue.data(userData);

    final isPro = userData.legacyUserData.isPro;
    if (!isPro) {
      resetServerLocation();
    }
    checkIfUserProAndDeviceIsAdded();
  }

  Future<Either<Failure, Unit>> updateLocale(String locale) {
    final result = ref.read(lanternServiceProvider).updateLocal(locale);
    return result;
  }

  /// Resets the server location to default.
  /// if user logs out or downgrade to free plan
  /// we need to reset the server location set to smart location
  void resetServerLocation() {
    final serverLocation = ref.read(serverLocationProvider);

    if (serverLocation.serverType.toServerLocationType ==
        ServerLocationType.lanternLocation) {
      ref
          .read(serverLocationProvider.notifier)
          .updateServerLocation(initialServerLocation());
    }
  }

  /// Fetches the latest user data from the server if not cached locally.
  Future<void> fetchUserDataIfNeeded() async {
    appLogger.info("Checking if user data fetch is needed...");
    appLogger.info("Fetching from Go (source-of-truth)...");
    await refreshUser();
  }

  /// Checks if the user is a Pro user and if the current device is added
  /// means user has logged in from this device before an did not logout.
  /// Updates the app settings accordingly and make user logged in automatically.
  void checkIfUserProAndDeviceIsAdded() {
    final user = state.value;
    if (user == null) {
      appLogger.error("User data is not available to check devices.");
      return;
    }
    _checkIfUserProAndDeviceIsAdded(user);
  }

  void _checkIfUserProAndDeviceIsAdded(UserResponseModel user) {
    if (!user.legacyUserData.isPro) {
      appLogger.info("User is not Pro. Skipping device check.");
      return;
    }
    final appSetting = ref.read(appSettingProvider);
    if (appSetting.userLoggedIn) {
      appLogger.info("User is already logged in. Skipping device check.");
      return;
    }
    final userDeviceId = user.legacyUserData.deviceID;
    final isDeviceAdded = user.legacyUserData.devices.any(
      (device) => device.deviceId == userDeviceId,
    );
    appLogger.info("Current device is linked to the account: $isDeviceAdded");
    if (isDeviceAdded) {
      ref.read(appSettingProvider.notifier).setUserLoggedIn(true);
      appLogger.info(
        "User is Pro and device is added. Logging in automatically.",
      );
    }
  }

  /// Clear any user-specific data upon logout.
  /// Updates server location to fastest.
  /// Fetches available servers again.
  void clearLogoutData() {
    ref.read(referralProvider.notifier).resetReferral();
    ref.read(appSettingProvider.notifier).setUserLoggedIn(false);
    // Defensive: a stale payment-in-flight flag would protect future
    // unrelated signup back-presses from deleting orphaned anonymous accounts.
    ref.read(paymentSessionProvider.notifier).clearRedirect();
  }
}
