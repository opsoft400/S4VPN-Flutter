package stub

import "github.com/sagernet/sing-box/experimental/libbox"

func NewPlatformInterfaceStub() libbox.PlatformInterface {
	return &platformInterfaceStub{}
}

type platformInterfaceStub struct {
}

func (p *platformInterfaceStub) LocalDNSTransport() libbox.LocalDNSTransport { return nil }
func (p *platformInterfaceStub) SystemCertificates() libbox.StringIterator   { return nil }

// AutoDetectInterfaceControl implements libbox.PlatformInterface.
func (p *platformInterfaceStub) AutoDetectInterfaceControl(fd int32) error {
	return nil
}

// ClearDNSCache implements libbox.PlatformInterface.
func (p *platformInterfaceStub) ClearDNSCache() {
}

// CloseDefaultInterfaceMonitor implements libbox.PlatformInterface.
func (p *platformInterfaceStub) CloseDefaultInterfaceMonitor(listener libbox.InterfaceUpdateListener) error {
	return nil
}

// FindConnectionOwner implements libbox.PlatformInterface.
func (p *platformInterfaceStub) FindConnectionOwner(ipProtocol int32, sourceAddress string, sourcePort int32, destinationAddress string, destinationPort int32) (*libbox.ConnectionOwner, error) {
	panic("unimplemented")
}

// GetInterfaces implements libbox.PlatformInterface.
func (p *platformInterfaceStub) GetInterfaces() (libbox.NetworkInterfaceIterator, error) {
	panic("unimplemented")
}

// IncludeAllNetworks implements libbox.PlatformInterface.
func (p *platformInterfaceStub) IncludeAllNetworks() bool {
	return false
}

// OpenTun implements libbox.PlatformInterface.
func (p *platformInterfaceStub) OpenTun(options libbox.TunOptions) (int32, error) {
	panic("unimplemented")
}

// ReadWIFIState implements libbox.PlatformInterface.
func (p *platformInterfaceStub) ReadWIFIState() *libbox.WIFIState {
	return nil
}

// SendNotification implements libbox.PlatformInterface.
func (p *platformInterfaceStub) SendNotification(notification *libbox.Notification) error {
	return nil
}

// StartDefaultInterfaceMonitor implements libbox.PlatformInterface.
func (p *platformInterfaceStub) StartDefaultInterfaceMonitor(listener libbox.InterfaceUpdateListener) error {
	return nil
}

// UnderNetworkExtension implements libbox.PlatformInterface.
func (p *platformInterfaceStub) UnderNetworkExtension() bool {
	return false
}

// UsePlatformAutoDetectInterfaceControl implements libbox.PlatformInterface.
func (p *platformInterfaceStub) UsePlatformAutoDetectInterfaceControl() bool {
	return false
}

// UseProcFS implements libbox.PlatformInterface.
func (p *platformInterfaceStub) UseProcFS() bool {
	return false
}
