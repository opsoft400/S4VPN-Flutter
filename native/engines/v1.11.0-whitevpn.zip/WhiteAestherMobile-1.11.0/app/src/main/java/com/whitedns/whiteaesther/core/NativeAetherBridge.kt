package com.whitedns.whiteaesther.core

import org.json.JSONObject

fun interface NativeSocketProtector {
    fun protectSocket(fd: Int): Boolean
}

fun interface NativeEngineListener {
    fun onNativeReady()
}

data class PreparedEngine(
    val ipv4: String,
    val ipv6: String,
    val peer: String,
)

data class NativeResult(
    val ok: Boolean,
    val error: String? = null,
)

data class EndpointScanResult(
    val peer: String,
    val rttMillis: Long,
)

object NativeAetherBridge {
    val loadResult: Result<Unit> by lazy {
        runCatching { System.loadLibrary("whiteaesther_core") }
    }

    val isLoaded: Boolean
        get() = loadResult.isSuccess

    fun versionOrNull(): String? = loadResult.mapCatching { nativeVersion() }.getOrNull()

    /**
     * Packages this install's identity so it survives a reinstall.
     *
     * Uninstalling takes the identity with it, and Cloudflare rate-limits device
     * registrations per address -- so a few reinstalls can leave the address
     * refused outright, which looks exactly like a broken app.
     */
    fun exportIdentity(configPath: String): Result<String> =
        call { nativeExportIdentity(configPath) }.mapCatching { raw ->
            val json = JSONObject(raw)
            check(json.optBoolean("ok")) { json.optString("error", "Nothing to export") }
            json.getString("payload")
        }

    /**
     * Restores an identity produced by [exportIdentity].
     *
     * Everything is checked before anything is written: a half-finished import
     * would leave the device holding an identity Cloudflare does not recognise,
     * with the working one already gone.
     */
    fun importIdentity(configPath: String, payload: String): NativeResult =
        call { nativeImportIdentity(configPath, payload) }.toResult()

    /**
     * Takes the engine's own log since the last call.
     *
     * The engine explains itself as it works -- which endpoint it is testing,
     * which obfuscation profile answered, why a handshake failed. Without this
     * none of it reaches the diagnostics report, so a user whose phone will not
     * connect has nothing to send that says why, and the developer is left
     * guessing on hardware that works.
     */
    fun drainLog(): List<String> {
        if (!isLoaded) return emptyList()
        return runCatching { nativeDrainLog()?.filterNotNull().orEmpty() }.getOrDefault(emptyList())
    }

    fun validate(configJson: String): NativeResult = call { validateConfig(configJson) }.toResult()

    fun prepare(configJson: String): Result<PreparedEngine> = call { nativePrepare(configJson) }
        .fold(
            onSuccess = { raw ->
                runCatching {
                    val json = JSONObject(raw)
                    check(json.optBoolean("ok")) { json.optString("error", "Preparation failed") }
                    PreparedEngine(
                        ipv4 = json.getString("ipv4"),
                        ipv6 = json.getString("ipv6"),
                        peer = json.getString("peer"),
                    )
                }
            },
            onFailure = { Result.failure(it) },
        )

    /**
     * Buys the engine's identity without building anything with it.
     *
     * For the moment another carrier is already carrying traffic. A Cloudflare
     * registration is the one thing the engine cannot do without and the one
     * thing a blocked network will not let it do -- so it is done through the
     * route that is working, once, and every later connect can be the engine's
     * own direct one.
     *
     * No endpoint search: that is the slow half of preparing, several thousand
     * probes, and none of it is needed to register. Returns the devices this
     * install now holds, which is nothing new when it already had them.
     */
    fun provision(configJson: String): Result<List<String>> = call { nativeProvision(configJson) }
        .mapCatching { raw ->
            val json = JSONObject(raw)
            check(json.optBoolean("ok")) { json.optString("error", "Provisioning failed") }
            val devices = json.getJSONArray("devices")
            List(devices.length()) { devices.getString(it) }
        }

    fun scan(configJson: String): Result<List<EndpointScanResult>> = call { nativeScan(configJson) }
        .mapCatching { raw ->
            val json = JSONObject(raw)
            check(json.optBoolean("ok")) { json.optString("error", "Endpoint scan failed") }
            val results = json.getJSONArray("results")
            List(results.length()) { index -> results.getJSONObject(index).toEndpointScanResult() }
        }

    fun testEndpoint(configJson: String): Result<EndpointScanResult> = call {
        nativeTestEndpoint(configJson)
    }.mapCatching { raw ->
        val json = JSONObject(raw)
        check(json.optBoolean("ok")) { json.optString("error", "Endpoint test failed") }
        json.toEndpointScanResult()
    }

    fun cancelScan(): Boolean = isLoaded && nativeCancelScan()

    /**
     * Ends a [prepare] that is still running.
     *
     * [cancelScan] does not: that one belongs to the standalone endpoint
     * search, and prepare's own provisioning and peer selection never heard it.
     *
     * @return true when there was a preparation to end.
     */
    fun cancelPrepare(): Boolean = isLoaded && nativeCancelPrepare()

    /**
     * Moves a running tunnel onto the network this phone is on now.
     *
     * Returns whether there was one able to do it. Only the QUIC path can: H2
     * rides TCP and a moved interface closes it outright, and WireGuard rebinds
     * by its own route. A false is not a failure -- it is the ordinary answer
     * for those two, and the caller reconnects as it always did.
     *
     * Worth trying first because the alternative is a reconnect, and a
     * reconnect on these networks means another endpoint search.
     */
    fun migrate(): Boolean = isLoaded && runCatching { nativeMigrate() }.getOrDefault(false)

    fun run(
        configJson: String,
        preparedPeer: String,
        tunFd: Int,
        listener: NativeEngineListener,
    ): NativeResult = call {
        nativeRun(configJson, preparedPeer, tunFd, listener)
    }.toResult()

    fun stop(): Boolean = isLoaded && nativeStop()

    fun setSocketProtector(protector: NativeSocketProtector?) {
        loadResult.getOrThrow()
        nativeSetSocketProtector(protector)
    }

    private inline fun call(block: () -> String): Result<String> = loadResult.fold(
        onSuccess = { runCatching(block) },
        onFailure = { Result.failure(it) },
    )

    private fun Result<String>.toResult(): NativeResult = fold(
        onSuccess = { raw ->
            runCatching {
                val json = JSONObject(raw)
                NativeResult(
                    ok = json.optBoolean("ok"),
                    error = json.optString("error").takeIf(String::isNotBlank),
                )
            }.getOrElse { NativeResult(false, "Invalid native response: ${it.message}") }
        },
        onFailure = { NativeResult(false, "Native core unavailable: ${it.message}") },
    )

    private fun JSONObject.toEndpointScanResult() = EndpointScanResult(
        peer = getString("peer"),
        rttMillis = getLong("rttMs"),
    )

    @JvmStatic
    private external fun nativeVersion(): String

    @JvmStatic
    private external fun validateConfig(configJson: String): String
    private external fun nativeDrainLog(): Array<String?>?
    private external fun nativeExportIdentity(configPath: String): String
    private external fun nativeImportIdentity(configPath: String, payload: String): String

    @JvmStatic
    private external fun nativePrepare(configJson: String): String

    @JvmStatic
    private external fun nativeProvision(configJson: String): String

    @JvmStatic
    private external fun nativeScan(configJson: String): String

    @JvmStatic
    private external fun nativeTestEndpoint(configJson: String): String

    @JvmStatic
    private external fun nativeCancelScan(): Boolean

    @JvmStatic
    private external fun nativeCancelPrepare(): Boolean

    @JvmStatic
    private external fun nativeMigrate(): Boolean

    @JvmStatic
    private external fun nativeRun(
        configJson: String,
        preparedPeer: String,
        tunFd: Int,
        listener: NativeEngineListener,
    ): String

    @JvmStatic
    private external fun nativeStop(): Boolean

    @JvmStatic
    private external fun nativeSetSocketProtector(protector: NativeSocketProtector?)
}
