use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::time::{Duration, Instant};

use futures::stream::StreamExt;
use rand::RngExt;

use crate::error::{AetherError, Result};
use crate::noize::NoizeConfig;
use crate::quic;

pub const MASQUE_DOCUMENTED_CIDRS_V4: &[&str] = &["162.159.197.0/24", "162.159.198.0/24"];

pub const MASQUE_DOH_CIDRS_V4: &[&str] = &["162.159.36.0/24", "162.159.46.0/24"];

pub const MASQUE_CIDRS_V4: &[&str] = &[
    "162.159.196.0/24",
    "162.159.195.0/24",
    "162.159.192.0/24",
    "162.159.193.0/24",
    "162.159.204.0/24",
    "162.159.197.0/24",
    "162.159.198.0/24",
    "172.65.251.0/24",
    "188.114.96.0/24",
    "188.114.97.0/24",
    "188.114.98.0/24",
    "188.114.99.0/24",
    "162.159.36.0/24",
    "162.159.46.0/24",
];

/// The dedicated WARP ranges above are where an endpoint is most likely to be,
/// but they are not the only place one lives: Cloudflare anycasts the MASQUE
/// endpoint across its edge, and 104.25.202.52 -- squarely in the CDN range and
/// in none of the ranges above -- was confirmed working from an Iranian network
/// the scan had reported as empty. These are searched after the dedicated
/// ranges, on 443 only, since that is the port the edge serves.
pub const MASQUE_CDN_CIDRS_V4: &[&str] = &[
    "104.16.0.0/16",
    "104.17.0.0/16",
    "104.18.0.0/16",
    "104.19.0.0/16",
    "104.24.0.0/16",
    "104.25.0.0/16",
    "104.26.0.0/16",
    "104.27.0.0/16",
    "172.64.0.0/16",
    "172.66.0.0/16",
    "172.67.0.0/16",
    "103.21.244.0/22",
    "103.22.200.0/22",
    "141.101.64.0/18",
    "190.93.240.0/20",
    "198.41.128.0/17",
];

pub const MASQUE_SEEDS: &[&str] = &[
    "162.159.196.1",
    "162.159.195.1",
    "162.159.192.1",
    "162.159.197.3",
    "162.159.197.1",
    "162.159.198.2",
    "162.159.198.1",
    "162.159.193.1",
];

pub const MASQUE_VERIFIED_GATEWAYS: &[&str] = &[
    "162.159.199.1",
    "162.159.199.2",
    "162.159.198.2",
    "162.159.198.1",
];

pub const MASQUE_ALT_PORTS: &[u16] = &[1701, 8095, 500, 4500];

pub const MASQUE_PORTS: &[u16] = &[443, 500, 1701, 4500, 4443, 8443, 8095];

pub const MASQUE_CIDRS_V6: &[&str] = &[
    "2606:4700:d0::/48",
    "2606:4700:102::/48",
    "2606:4700:d1::/48",
];

pub const MASQUE_ZT_CIDRS_V4: &[&str] = &["162.159.197.0/24"];

pub const MASQUE_ZT_CIDRS_V6: &[&str] = &["2606:4700:102::/48"];

pub fn zero_trust_mode() -> bool {
    std::env::var("AETHER_TEAM")
        .map(|value| !value.trim().is_empty())
        .unwrap_or(false)
}

pub fn prioritize(all: &[&'static str], first: &[&'static str]) -> Vec<&'static str> {
    if !zero_trust_mode() {
        return all.to_vec();
    }

    let mut out: Vec<&'static str> = Vec::with_capacity(all.len());
    for entry in first {
        if all.contains(entry) {
            out.push(entry);
        }
    }
    for entry in all {
        if !out.contains(entry) {
            out.push(entry);
        }
    }
    out
}

pub fn masque_cidrs_v4() -> Vec<&'static str> {
    prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4)
}

pub fn masque_cidrs_v6() -> Vec<&'static str> {
    prioritize(MASQUE_CIDRS_V6, MASQUE_ZT_CIDRS_V6)
}

pub const MASQUE_SEEDS_V6: &[&str] = &[
    "2606:4700:d0::a29f:c602",
    "2606:4700:d1::a29f:c602",
    "2606:4700:d0::a29f:c601",
    "2606:4700:d0::a29f:c001",
];

#[derive(Debug, Clone, Copy)]
pub struct ProbeResult {
    pub ip: IpAddr,
    pub port: u16,
    pub rtt: Duration,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IpScan {
    V4,
    V6,
    Both,
}

impl IpScan {
    pub fn parse(s: &str) -> IpScan {
        match s.trim().to_lowercase().as_str() {
            "6" | "v6" | "ipv6" => IpScan::V6,
            "both" | "all" | "dual" => IpScan::Both,
            _ => IpScan::V4,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            IpScan::V4 => "ipv4",
            IpScan::V6 => "ipv6",
            IpScan::Both => "dual-stack",
        }
    }

    pub fn want_v4(&self) -> bool {
        matches!(self, IpScan::V4 | IpScan::Both)
    }

    pub fn want_v6(&self) -> bool {
        matches!(self, IpScan::V6 | IpScan::Both)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScanMode {
    Turbo,
    Balanced,
    Thorough,
    Verified,
    Ironclad,
}

impl ScanMode {
    pub fn parse(s: &str) -> ScanMode {
        match s.trim().to_lowercase().as_str() {
            "turbo" | "fast" => ScanMode::Turbo,
            "thorough" | "deep" | "pro" => ScanMode::Thorough,
            "verified" | "proven" | "stealth" | "quiet" => ScanMode::Verified,
            "ironclad" | "real" | "verify" | "guaranteed" => ScanMode::Ironclad,
            _ => ScanMode::Balanced,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            ScanMode::Turbo => "turbo",
            ScanMode::Balanced => "balanced",
            ScanMode::Thorough => "thorough",
            ScanMode::Verified => "verified",
            ScanMode::Ironclad => "ironclad",
        }
    }

    /// Concurrency and overall budget, for the cross-prober comparison in
    /// `lib.rs`. The two strategies are private and differently shaped; this is
    /// the pair that decides how much of the space gets searched.
    #[cfg(test)]
    pub(crate) fn strategy_for_test(&self) -> (usize, Duration) {
        let s = self.strategy();
        (s.concurrency, s.overall_deadline)
    }

    fn strategy(&self) -> Strategy {
        let mut strategy = match self {
            ScanMode::Turbo => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(45),
                quiet_after_first: Duration::from_secs(0),
                target_successes: 1,
                early_exit_first: true,
                full_subnet: false,
                sample_per_cidr: 64,
            },
            ScanMode::Balanced => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(120),
                quiet_after_first: Duration::from_secs(20),
                target_successes: 6,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
            ScanMode::Thorough => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(10000),
                overall_deadline: Duration::from_secs(300),
                quiet_after_first: Duration::from_secs(30),
                target_successes: 0,
                early_exit_first: false,
                full_subnet: true,
                sample_per_cidr: 0,
            },
            ScanMode::Verified => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(5000),
                overall_deadline: Duration::from_secs(60),
                quiet_after_first: Duration::from_secs(8),
                target_successes: 4,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 48,
            },
            ScanMode::Ironclad => Strategy {
                concurrency: 4,
                per_probe_timeout: Duration::from_millis(15000),
                overall_deadline: Duration::from_secs(180),
                quiet_after_first: Duration::from_secs(15),
                target_successes: 3,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
        };
        if matches!(self, ScanMode::Turbo)
            && std::env::var("AETHER_CONNECT_FAST").as_deref() == Ok("1")
        {
            strategy.overall_deadline = Duration::from_secs(12);
            strategy.per_probe_timeout = Duration::from_secs(3);
            strategy.concurrency = 8;
        }
        strategy
    }
}

const IRONCLAD_TCPING_TIMEOUT: Duration = Duration::from_secs(10);

struct Strategy {
    concurrency: usize,
    per_probe_timeout: Duration,
    overall_deadline: Duration,
    quiet_after_first: Duration,
    target_successes: usize,
    early_exit_first: bool,
    full_subnet: bool,
    sample_per_cidr: usize,
}

#[derive(Clone)]
pub struct MasqueProbe {
    pub sni: String,
    pub authority: String,
    pub path: String,
    pub cert_pem: Arc<[u8]>,
    pub key_pem: Arc<[u8]>,
    pub ech_config_list: Option<Arc<[u8]>>,
    pub noize: NoizeConfig,
    pub ports: Vec<u16>,
    pub ip: IpScan,
    pub local_ipv4: Ipv4Addr,
}

pub async fn host_has_ipv6() -> bool {
    match crate::egress::udp_bind("[::]:0".parse().expect("a wildcard address")) {
        Ok(sock) => sock.connect("[2606:4700:d0::a29f:c001]:443").await.is_ok(),
        Err(_) => false,
    }
}

/// Why one MASQUE probe produced no gateway.
///
/// Classified rather than discarded. Every failure used to become `None` at
/// trace level, so three thousand probes failing for one reason and three
/// thousand failing because the network is hostile ended as the same sentence:
/// `no clean endpoint found`. That sentence blames the network, and in the
/// incident that produced this it was wrong every time.
///
/// Read off the error variant where the variant is enough, and off the message
/// only for the finer splits the variants do not carry. The types underneath --
/// quic, masque_h2, tls -- still speak in strings; narrowing that is a larger
/// change than this, and this is the part that decides what the engine does
/// next.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum ProbeFailure {
    /// Nothing came back before the deadline.
    NoAnswer,
    /// The address refused the connection outright.
    Refused,
    /// TLS completed and the certificate was not one we accept.
    PinMismatch,
    /// TLS itself would not complete.
    TlsRejected,
    /// The gateway answered the connect-ip request with a refusal.
    ConnectIpRefused,
    /// A tunnel opened and closed before carrying anything.
    NoDataPlane,
    Other,
}

impl ProbeFailure {
    pub fn label(self) -> &'static str {
        match self {
            ProbeFailure::NoAnswer => "no answer",
            ProbeFailure::Refused => "refused",
            ProbeFailure::PinMismatch => "certificate not ours",
            ProbeFailure::TlsRejected => "tls refused",
            ProbeFailure::ConnectIpRefused => "connect-ip refused",
            ProbeFailure::NoDataPlane => "opened, carried nothing",
            ProbeFailure::Other => "other",
        }
    }

    /// Whether every address in the pool would fail this way.
    ///
    /// A certificate we do not accept, or a request the gateway refuses, is a
    /// fault in what we are sending -- not in which address we sent it to. No
    /// number of further probes changes it, and spending the budget to confirm
    /// that is how a fixable fault comes to look like censorship.
    pub fn is_common_mode(self) -> bool {
        matches!(
            self,
            ProbeFailure::PinMismatch | ProbeFailure::ConnectIpRefused
        )
    }

    fn of(error: &AetherError) -> Self {
        let text = error.to_string().to_ascii_lowercase();
        match error {
            AetherError::Tls(_) if text.contains("application verification") => {
                ProbeFailure::PinMismatch
            }
            AetherError::Tls(_) => ProbeFailure::TlsRejected,
            AetherError::Io(e) if e.kind() == std::io::ErrorKind::ConnectionRefused => {
                ProbeFailure::Refused
            }
            AetherError::Io(e) if e.kind() == std::io::ErrorKind::TimedOut => {
                ProbeFailure::NoAnswer
            }
            _ if text.contains("connect-ip status") => ProbeFailure::ConnectIpRefused,
            _ if text.contains("before data-plane") || text.contains("carried anything") => {
                ProbeFailure::NoDataPlane
            }
            _ if text.contains("timed out") || text.contains("deadline") => ProbeFailure::NoAnswer,
            _ if text.contains("refused") => ProbeFailure::Refused,
            _ => ProbeFailure::Other,
        }
    }
}

/// What a run of probes ran into, for the log and for the decision to stop.
#[derive(Debug, Default, Clone)]
pub struct FailureTally {
    counts: std::collections::BTreeMap<ProbeFailure, usize>,
    total: usize,
}

/// Probes to see before one repeated answer is believed to be about all of them.
const COMMON_MODE_SAMPLE: usize = 40;

/// The share of that sample one kind has to hold.
const COMMON_MODE_SHARE: f64 = 0.9;

impl FailureTally {
    fn record(&mut self, kind: ProbeFailure) {
        *self.counts.entry(kind).or_insert(0) += 1;
        self.total += 1;
    }

    /// The kind that is answering for effectively all of them, if there is one.
    fn common_mode(&self) -> Option<(ProbeFailure, usize)> {
        if self.total < COMMON_MODE_SAMPLE {
            return None;
        }
        self.counts
            .iter()
            .find(|(kind, count)| {
                kind.is_common_mode() && **count as f64 >= self.total as f64 * COMMON_MODE_SHARE
            })
            .map(|(kind, count)| (*kind, *count))
    }

    pub fn summary(&self) -> String {
        if self.total == 0 {
            return "nothing was probed".to_string();
        }
        self.counts
            .iter()
            .map(|(kind, count)| format!("{}={count}", kind.label()))
            .collect::<Vec<_>>()
            .join(" ")
    }
}

pub async fn hunt_best_gateway(probe: &MasqueProbe, mode: ScanMode) -> Result<ProbeResult> {
    let mut st = mode.strategy();
    st.concurrency = crate::sysprofile::cap_concurrency(st.concurrency);
    let timeout = st.per_probe_timeout;
    let mut effective_ip = probe.ip;
    if probe.ip.want_v6() && !host_has_ipv6().await {
        if probe.ip.want_v4() {
            log::warn!("[-] host has no IPv6 route; falling back to IPv4-only scan");
            effective_ip = IpScan::V4;
        } else {
            log::warn!("[-] host has no IPv6 route; IPv6 scan needs native IPv6 connectivity");
            return Err(AetherError::NoCleanEndpoint);
        }
    }
    let candidates = build_candidates(&st, &probe.ports, effective_ip);

    log::info!(
        "[*] scan mode={} ip={} candidates={} ports={:?} concurrency={} per_probe={:?} budget={:?}",
        mode.label(),
        effective_ip.label(),
        candidates.len(),
        probe.ports,
        st.concurrency,
        st.per_probe_timeout,
        st.overall_deadline,
    );

    let ironclad = mode == ScanMode::Ironclad;

    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| verify_one(probe, ip, port, timeout, ironclad)),
    )
    .buffer_unordered(st.concurrency);
    tokio::pin!(stream);

    let deadline = Instant::now() + st.overall_deadline;
    let mut best: Option<ProbeResult> = None;
    let mut found = 0usize;
    let mut quiet_until: Option<Instant> = None;
    let mut tally = FailureTally::default();

    loop {
        let effective = match quiet_until {
            Some(q) => q.min(deadline),
            None => deadline,
        };
        let remaining = effective.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            if best.is_some() {
                if quiet_until.is_some() {
                    log::info!("[+] no new gateways recently, finalizing selection");
                } else {
                    log::warn!("[-] scan deadline reached");
                }
            } else {
                log::warn!(
                    "[-] scan deadline reached with no gateway ({})",
                    tally.summary()
                );
            }
            break;
        }

        tokio::select! {
            item = stream.next() => {
                match item {
                    None => break,
                    Some(Err(why)) => {
                        tally.record(why);
                        // One answer repeated by everything is about what we are
                        // sending, not about where we sent it. Confirming that
                        // across the remaining candidates costs the whole budget
                        // and teaches nothing.
                        if best.is_none() {
                            if let Some((kind, count)) = tally.common_mode() {
                                log::warn!(
                                    "[-] stopping the scan: {count} of {} probes answered the same                                      way ({}), which is not about the address",
                                    tally.total,
                                    kind.label()
                                );
                                return Err(AetherError::Other(format!(
                                    "every gateway answered the same way ({}); this is not the                                      network",
                                    kind.label()
                                )));
                            }
                        }
                        continue;
                    }
                    Some(Ok(pr)) => {
                        log::info!("[+] candidate ok {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
                        if st.early_exit_first {
                            return Ok(pr);
                        }
                        best = Some(match best {
                            Some(cur) if cur.rtt <= pr.rtt => cur,
                            _ => pr,
                        });
                        found += 1;

                        if st.target_successes > 0 && found >= st.target_successes && quiet_until.is_none() {
                            log::info!("[+] reached target of {} gateways, selecting best", st.target_successes);
                            if !st.quiet_after_first.is_zero() {
                                quiet_until = Some(Instant::now() + st.quiet_after_first);
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
            _ = tokio::time::sleep(remaining) => {
                if best.is_some() {
                    if quiet_until.is_some() {
                        log::info!("[+] no new gateways recently, finalizing selection");
                    } else {
                        log::warn!("[-] scan deadline reached");
                    }
                } else {
                    log::warn!(
                        "[-] scan deadline reached with no gateway ({})",
                        tally.summary()
                    );
                }
                break;
            }
        }
    }

    match best {
        Some(pr) => {
            log::info!("[+] best gateway {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
            Ok(pr)
        }
        None => {
            log::warn!("[-] nothing answered ({})", tally.summary());
            Err(AetherError::NoCleanEndpoint)
        }
    }
}

pub async fn scan_gateways(
    probe: &MasqueProbe,
    mode: ScanMode,
    limit: usize,
    cancelled: &AtomicBool,
) -> Result<Vec<ProbeResult>> {
    let mut st = mode.strategy();
    st.concurrency = crate::sysprofile::cap_concurrency(st.concurrency);
    let timeout = st.per_probe_timeout;
    let mut effective_ip = probe.ip;
    if probe.ip.want_v6() && !host_has_ipv6().await {
        if probe.ip.want_v4() {
            effective_ip = IpScan::V4;
        } else {
            return Err(AetherError::NoCleanEndpoint);
        }
    }
    let candidates = build_candidates(&st, &probe.ports, effective_ip);
    let ironclad = mode == ScanMode::Ironclad;
    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| verify_one(probe, ip, port, timeout, ironclad)),
    )
    .buffer_unordered(st.concurrency);
    tokio::pin!(stream);

    let limit = limit.clamp(1, 16);
    let deadline = Instant::now() + st.overall_deadline;
    let mut quiet_until: Option<Instant> = None;
    let mut results = Vec::new();

    loop {
        if cancelled.load(Ordering::Relaxed) {
            return Err(AetherError::Other("endpoint scan cancelled".into()));
        }
        let effective = quiet_until.map_or(deadline, |quiet| quiet.min(deadline));
        let remaining = effective.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            break;
        }

        tokio::select! {
            item = stream.next() => {
                match item {
                    None => break,
                    Some(Err(_)) => continue,
                    Some(Ok(result)) => {
                        if !results.iter().any(|existing: &ProbeResult| {
                            existing.ip == result.ip && existing.port == result.port
                        }) {
                            results.push(result);
                            results.sort_by_key(|entry| entry.rtt);
                            if results.len() >= limit {
                                break;
                            }
                        }
                        if st.quiet_after_first.is_zero() {
                            break;
                        }
                        quiet_until = Some(Instant::now() + st.quiet_after_first);
                    }
                }
            }
            _ = tokio::time::sleep(remaining) => break,
            _ = tokio::time::sleep(Duration::from_millis(100)) => {}
        }
    }

    if cancelled.load(Ordering::Relaxed) {
        return Err(AetherError::Other("endpoint scan cancelled".into()));
    }
    if results.is_empty() {
        Err(AetherError::NoCleanEndpoint)
    } else {
        Ok(results)
    }
}

async fn verify_one(
    probe: &MasqueProbe,
    ip: IpAddr,
    port: u16,
    timeout: Duration,
    ironclad: bool,
) -> std::result::Result<ProbeResult, ProbeFailure> {
    if ironclad {
        let params = crate::tunnelping::MasquePingParams {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            ech_config_list: probe.ech_config_list.as_ref().map(|a| a.to_vec()),
            noize: probe.noize.clone(),
            local_ipv4: probe.local_ipv4,
            local_ipv4_str: probe.local_ipv4.to_string(),
            local_ipv6_str: String::new(),
        };
        return match crate::tunnelping::masque_http_ping(&params, IRONCLAD_TCPING_TIMEOUT).await {
            Ok(rtt) => {
                log::info!(
                    "[+] ironclad verified {ip}:{port} real http round trip rtt={:?}",
                    rtt
                );
                Ok(ProbeResult { ip, port, rtt })
            }
            Err(e) => {
                log::debug!("[-] ironclad {ip}:{port} failed real http check: {e}");
                Err(ProbeFailure::of(&e))
            }
        };
    }

    if crate::masque_h2::enabled() {
        let cfg = crate::masque_h2::H2TunnelConfig {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            local_ipv4: probe.local_ipv4,
            quiet: true,
            pin_endpoint: true,
            expected_pins: crate::consts::masque_pins()
                .iter()
                .map(|p| p.to_vec())
                .collect(),
            ech_config_list: probe.ech_config_list.as_ref().map(|a| a.to_vec()),
        };
        return match crate::masque_h2::verify_h2(&cfg, timeout).await {
            Ok(rtt) => Ok(ProbeResult { ip, port, rtt }),
            Err(e) => {
                log::debug!("h2 probe {ip}:{port} -> {e}");
                Err(ProbeFailure::of(&e))
            }
        };
    }

    let vp = quic::VerifyParams {
        peer: SocketAddr::new(ip, port),
        sni: probe.sni.clone(),
        authority: probe.authority.clone(),
        path: probe.path.clone(),
        cert_pem: probe.cert_pem.to_vec(),
        key_pem: probe.key_pem.to_vec(),
        ech_config_list: probe.ech_config_list.as_ref().map(|a| a.to_vec()),
        noize: probe.noize.clone(),
        timeout,
        local_ipv4: probe.local_ipv4,
    };

    match quic::verify_masque(&vp).await {
        Ok(rtt) => Ok(ProbeResult { ip, port, rtt }),
        Err(e) => {
            log::debug!("probe {ip}:{port} -> {e}");
            Err(ProbeFailure::of(&e))
        }
    }
}

fn build_candidates(st: &Strategy, ports: &[u16], ip: IpScan) -> Vec<(IpAddr, u16)> {
    let primary = ports.first().copied().unwrap_or(443);
    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();

    let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();
    let seeds6: Vec<Ipv6Addr> = MASQUE_SEEDS_V6
        .iter()
        .filter_map(|s| s.parse().ok())
        .collect();

    if ip.want_v4() {
        for a in &seeds {
            if seen.insert((IpAddr::V4(*a), primary)) {
                out.push((IpAddr::V4(*a), primary));
            }
        }
        let cidr_hosts: Vec<Vec<Ipv4Addr>> = masque_cidrs_v4()
            .iter()
            .map(|c| {
                if st.full_subnet {
                    enumerate_cidr_v4(c)
                } else {
                    sample_cidr_v4(c, st.sample_per_cidr)
                }
            })
            .collect();
        let max_len = cidr_hosts.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for hosts in &cidr_hosts {
                if let Some(a) = hosts.get(i) {
                    if seen.insert((IpAddr::V4(*a), primary)) {
                        out.push((IpAddr::V4(*a), primary));
                    }
                }
            }
        }

        // Edge ranges last, so a network where the dedicated ranges answer is
        // unaffected and only one that finds nothing there pays for the wider
        // sweep. Sampled more thinly, because they are far larger and a smaller
        // share of them terminates MASQUE.
        if st.sample_per_cidr > 0 {
            let per = (st.sample_per_cidr / 4).max(8);
            let cdn: Vec<Vec<Ipv4Addr>> = MASQUE_CDN_CIDRS_V4
                .iter()
                .map(|c| sample_cidr_v4(c, per))
                .collect();
            let cdn_max = cdn.iter().map(|v| v.len()).max().unwrap_or(0);
            for i in 0..cdn_max {
                for hosts in &cdn {
                    if let Some(a) = hosts.get(i) {
                        if seen.insert((IpAddr::V4(*a), 443)) {
                            out.push((IpAddr::V4(*a), 443));
                        }
                    }
                }
            }
        }
    }

    if ip.want_v6() {
        for a in &seeds6 {
            if seen.insert((IpAddr::V6(*a), primary)) {
                out.push((IpAddr::V6(*a), primary));
            }
        }
        let per = if st.sample_per_cidr == 0 {
            96
        } else {
            st.sample_per_cidr
        };
        let cidr6: Vec<Vec<Ipv6Addr>> = masque_cidrs_v6()
            .iter()
            .map(|c| sample_cidr_v6(c, per, MASQUE_CIDRS_V4))
            .collect();
        let max6 = cidr6.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max6 {
            for hosts in &cidr6 {
                if let Some(a) = hosts.get(i) {
                    if seen.insert((IpAddr::V6(*a), primary)) {
                        out.push((IpAddr::V6(*a), primary));
                    }
                }
            }
        }
    }

    if ip.want_v4() {
        for a in &seeds {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V4(*a), port)) {
                    out.push((IpAddr::V4(*a), port));
                }
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V6(*a), port)) {
                    out.push((IpAddr::V6(*a), port));
                }
            }
        }
    }

    out
}

fn parse_cidr_v4(cidr: &str) -> Option<(u32, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u32::from(ip.parse::<Ipv4Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn enumerate_cidr_v4(cidr: &str) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    if host_bits == 0 {
        return vec![Ipv4Addr::from(base)];
    }
    if host_bits > 12 {
        return Vec::new();
    }
    let size = 1u32 << host_bits;
    (1..size.saturating_sub(1))
        .map(|off| Ipv4Addr::from(base + off))
        .collect()
}

fn sample_cidr_v4(cidr: &str, n: usize) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    let size = if host_bits >= 32 {
        u32::MAX
    } else {
        1u32 << host_bits
    };
    if size <= 2 {
        return vec![Ipv4Addr::from(base)];
    }

    let usable = size - 2;
    let want = (n as u32).min(usable);
    let mut rng = rand::rng();
    let mut chosen: HashSet<u32> = HashSet::with_capacity(want as usize);
    let mut out = Vec::with_capacity(want as usize);

    while (out.len() as u32) < want {
        let off = 1 + rng.random_range(0..usable);
        if chosen.insert(off) {
            out.push(Ipv4Addr::from(base + off));
        }
    }

    out
}

fn parse_cidr_v6(cidr: &str) -> Option<(u128, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u128::from(ip.parse::<Ipv6Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn sample_cidr_v6(cidr: &str, n: usize, v4_cidrs: &[&str]) -> Vec<Ipv6Addr> {
    let (base, prefix) = match parse_cidr_v6(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    if 128u32.saturating_sub(prefix as u32) == 0 {
        return vec![Ipv6Addr::from(base)];
    }

    let v4: Vec<(u32, u8)> = v4_cidrs.iter().filter_map(|c| parse_cidr_v4(c)).collect();
    let mut rng = rand::rng();
    let mut out = Vec::with_capacity(n);
    for _ in 0..n {
        let embedded = if v4.is_empty() {
            rng.random::<u32>() as u128
        } else {
            let (b, p) = v4[rng.random_range(0..v4.len())];
            let host_bits = 32u32.saturating_sub(p as u32);
            let host = if host_bits == 0 {
                0
            } else {
                rng.random::<u32>() & ((1u32 << host_bits) - 1)
            };
            (b | host) as u128
        };
        out.push(Ipv6Addr::from(base | embedded));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_documented_zero_trust_masque_ingress_range_is_scanned() {
        assert!(MASQUE_CIDRS_V4.contains(&"162.159.197.0/24"));
        assert!(MASQUE_CIDRS_V6.contains(&"2606:4700:102::/48"));
    }

    #[test]
    fn the_dns_over_https_ranges_are_swept_last_because_they_never_serve_masque() {
        let tail = &MASQUE_CIDRS_V4[MASQUE_CIDRS_V4.len() - MASQUE_DOH_CIDRS_V4.len()..];
        for entry in MASQUE_DOH_CIDRS_V4 {
            assert!(tail.contains(entry), "{entry} should be at the end");
        }
    }

    #[test]
    fn the_documented_default_masque_port_leads_the_sweep() {
        assert_eq!(MASQUE_PORTS.first(), Some(&443));
    }

    #[test]
    fn the_documented_masque_fallback_ports_keep_their_documented_order() {
        assert_eq!(MASQUE_PORTS, &[443, 500, 1701, 4500, 4443, 8443, 8095]);
    }

    #[test]
    fn without_a_team_the_range_order_is_left_alone() {
        std::env::remove_var("AETHER_TEAM");
        assert_eq!(
            prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4),
            MASQUE_CIDRS_V4.to_vec()
        );
    }

    #[test]
    fn prioritize_moves_the_wanted_entries_to_the_front_without_losing_any() {
        let all = ["a", "b", "c", "d"];
        let out = {
            let mut out: Vec<&'static str> = vec!["c"];
            for entry in all {
                if !out.contains(&entry) {
                    out.push(entry);
                }
            }
            out
        };
        assert_eq!(out, vec!["c", "a", "b", "d"]);
        assert_eq!(out.len(), all.len());
    }

    /// Everything answering the same way is not a statement about the network.
    ///
    /// The whole incident in miniature: a certificate we do not accept, or a
    /// request the gateway refuses, fails identically at every address. Spending
    /// the budget to confirm that across three thousand of them is how a
    /// fixable fault comes to look like censorship.
    #[test]
    fn one_answer_repeated_by_everything_stops_the_scan() {
        let mut tally = FailureTally::default();
        for _ in 0..COMMON_MODE_SAMPLE {
            tally.record(ProbeFailure::PinMismatch);
        }
        assert_eq!(
            Some((ProbeFailure::PinMismatch, COMMON_MODE_SAMPLE)),
            tally.common_mode(),
        );
    }

    /// A hostile network is not a common-mode fault, and must not stop the scan.
    ///
    /// Silence and refusal are exactly what a blocked address looks like, and
    /// the next address may well answer. Only a fault in what we send counts.
    #[test]
    fn a_network_that_drops_everything_does_not_stop_the_scan() {
        let mut tally = FailureTally::default();
        for _ in 0..COMMON_MODE_SAMPLE * 4 {
            tally.record(ProbeFailure::NoAnswer);
        }
        assert_eq!(None, tally.common_mode());

        let mut refused = FailureTally::default();
        for _ in 0..COMMON_MODE_SAMPLE * 4 {
            refused.record(ProbeFailure::Refused);
        }
        assert_eq!(None, refused.common_mode());
    }

    /// Too few probes is not evidence about the rest of them.
    #[test]
    fn a_handful_of_probes_is_not_enough_to_conclude_anything() {
        let mut tally = FailureTally::default();
        for _ in 0..COMMON_MODE_SAMPLE - 1 {
            tally.record(ProbeFailure::ConnectIpRefused);
        }
        assert_eq!(None, tally.common_mode());
        tally.record(ProbeFailure::ConnectIpRefused);
        assert!(tally.common_mode().is_some());
    }

    /// A mixture is a network, not a fault in what we send.
    #[test]
    fn a_mixture_of_answers_is_not_a_common_mode_fault() {
        let mut tally = FailureTally::default();
        for index in 0..COMMON_MODE_SAMPLE * 2 {
            tally.record(if index % 2 == 0 {
                ProbeFailure::PinMismatch
            } else {
                ProbeFailure::NoAnswer
            });
        }
        assert_eq!(None, tally.common_mode());
    }

    /// The failures the incident actually produced, named from the real errors.
    #[test]
    fn the_answers_this_incident_produced_are_classified() {
        let cases = [
            (
                AetherError::Tls(
                    "h2 tls handshake: TLS handshake failed: cert verification failed -                      application verification failure"
                        .into(),
                ),
                ProbeFailure::PinMismatch,
            ),
            (
                AetherError::Masque("h2 connect-ip status 400; cf-ray=-".into()),
                ProbeFailure::ConnectIpRefused,
            ),
            (
                AetherError::Other("closed before data-plane confirmation".into()),
                ProbeFailure::NoDataPlane,
            ),
            (
                AetherError::Tls("TLS handshake failed: handshake timed out".into()),
                ProbeFailure::TlsRejected,
            ),
        ];
        for (error, expected) in cases {
            assert_eq!(expected, ProbeFailure::of(&error), "{error}");
        }
    }

    /// The summary names every kind it saw, so a report can be read.
    #[test]
    fn the_summary_says_what_was_seen() {
        let mut tally = FailureTally::default();
        tally.record(ProbeFailure::NoAnswer);
        tally.record(ProbeFailure::NoAnswer);
        tally.record(ProbeFailure::PinMismatch);
        let summary = tally.summary();
        assert!(summary.contains("no answer=2"), "{summary}");
        assert!(summary.contains("certificate not ours=1"), "{summary}");
    }

    #[test]
    fn the_documented_masque_fallback_ports_are_all_covered() {
        for port in [443u16, 500, 1701, 4443, 4500, 8443, 8095] {
            assert!(
                MASQUE_PORTS.contains(&port),
                "documented fallback port {port} should be scanned"
            );
        }
    }

    async fn quic_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
        let bind = if peer.is_ipv4() {
            "0.0.0.0:0"
        } else {
            "[::]:0"
        };
        let sock = tokio::net::UdpSocket::bind(bind).await.ok()?;
        sock.connect(peer).await.ok()?;
        let local = sock.local_addr().ok()?;

        let mut config = quiche::Config::new(quiche::PROTOCOL_VERSION).ok()?;
        config.set_application_protos(&[b"h3"]).ok()?;
        config.verify_peer(false);
        config.set_max_idle_timeout(timeout.as_millis() as u64);
        config.set_initial_max_data(1_000_000);
        config.set_initial_max_stream_data_bidi_local(100_000);
        config.set_initial_max_streams_bidi(4);

        let mut scid = [0u8; 16];
        rand::rng().fill(&mut scid[..]);
        let scid = quiche::ConnectionId::from_ref(&scid);

        let sni = crate::consts::CONNECT_SNI;
        let mut conn = quiche::connect(Some(sni), &scid, local, peer, &mut config).ok()?;

        let mut out = [0u8; 1350];
        let (written, _) = conn.send(&mut out).ok()?;

        let started = Instant::now();
        sock.send(&out[..written]).await.ok()?;

        let mut buf = [0u8; 1500];
        match tokio::time::timeout(timeout, sock.recv(&mut buf)).await {
            Ok(Ok(read)) if read > 0 => Some(started.elapsed()),
            _ => None,
        }
    }

    async fn tcp_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
        let started = Instant::now();
        match tokio::time::timeout(timeout, tokio::net::TcpStream::connect(peer)).await {
            Ok(Ok(_)) => Some(started.elapsed()),
            _ => None,
        }
    }

    async fn first_answer(
        targets: &[SocketAddr],
        timeout: Duration,
        attempts: u32,
        udp: bool,
    ) -> Option<(SocketAddr, Duration)> {
        for _ in 0..attempts {
            let probes = targets.iter().copied().map(|peer| async move {
                let rtt = match udp {
                    true => quic_answers(peer, timeout).await,
                    false => tcp_answers(peer, timeout).await,
                };
                (peer, rtt)
            });

            let results: Vec<(SocketAddr, Option<Duration>)> = futures::stream::iter(probes)
                .buffer_unordered(targets.len().max(1))
                .collect()
                .await;

            if let Some((peer, Some(rtt))) = results.into_iter().find(|(_, rtt)| rtt.is_some()) {
                return Some((peer, rtt));
            }
        }
        None
    }

    fn hosts_of(cidr: &str, tails: &[u8]) -> Vec<Ipv4Addr> {
        let base: Ipv4Addr = cidr.split('/').next().unwrap().parse().expect("cidr base");
        let octets = base.octets();
        tails
            .iter()
            .map(|tail| Ipv4Addr::new(octets[0], octets[1], octets[2], *tail))
            .collect()
    }

    #[tokio::test(flavor = "multi_thread")]
    #[ignore = "probes the live cloudflare edge from this network to see which masque ranges answer"]
    async fn report_which_masque_ranges_answer_on_this_network() {
        const TAILS: &[u8] = &[1, 2, 3];

        let timeout = Duration::from_millis(
            std::env::var("AETHER_PROBE_TIMEOUT_MS")
                .ok()
                .and_then(|raw| raw.trim().parse::<u64>().ok())
                .filter(|ms| *ms > 0)
                .unwrap_or(10_000),
        );

        let attempts = std::env::var("AETHER_PROBE_ATTEMPTS")
            .ok()
            .and_then(|raw| raw.trim().parse::<u32>().ok())
            .filter(|n| *n > 0)
            .unwrap_or(2);

        let ports: Vec<u16> = match std::env::var("AETHER_PROBE_PORTS") {
            Ok(raw) => raw
                .split(',')
                .filter_map(|p| p.trim().parse::<u16>().ok())
                .collect(),
            Err(_) => vec![443],
        };
        let ports = if ports.is_empty() { vec![443] } else { ports };

        println!();
        println!("probing the masque ranges from this network");
        println!("  udp timeout {timeout:?}, {attempts} attempt(s), hosts {TAILS:?}");
        println!("  udp ports {ports:?}");
        println!("  override: AETHER_PROBE_TIMEOUT_MS, AETHER_PROBE_ATTEMPTS, AETHER_PROBE_PORTS");
        println!();

        let control: Vec<SocketAddr> = vec![
            "1.1.1.1:443".parse().unwrap(),
            "8.8.8.8:443".parse().unwrap(),
        ];

        let control_quic = first_answer(&control, timeout, attempts, true).await;
        let control_tcp = first_answer(&control, timeout, attempts, false).await;

        println!("control targets (public resolvers, not cloudflare warp edges)");
        match control_quic {
            Some((peer, rtt)) => println!("  quic/udp 443 works: {peer} in {}ms", rtt.as_millis()),
            None => println!("  quic/udp 443 got no answer at all"),
        }
        match control_tcp {
            Some((peer, rtt)) => println!("  tcp 443 works:      {peer} in {}ms", rtt.as_millis()),
            None => println!("  tcp 443 got no answer at all"),
        }
        println!();

        let mut udp_ok = Vec::new();
        let mut tcp_only = Vec::new();
        let mut silent = Vec::new();

        for cidr in MASQUE_CIDRS_V4 {
            let note = if MASQUE_DOCUMENTED_CIDRS_V4.contains(cidr) {
                " [documented]"
            } else if MASQUE_DOH_CIDRS_V4.contains(cidr) {
                " [dns-over-https]"
            } else {
                ""
            };

            let hosts = hosts_of(cidr, TAILS);

            let mut udp_hit: Option<(SocketAddr, Duration)> = None;
            for port in &ports {
                let targets: Vec<SocketAddr> = hosts
                    .iter()
                    .map(|ip| SocketAddr::new(IpAddr::V4(*ip), *port))
                    .collect();
                udp_hit = first_answer(&targets, timeout, attempts, true).await;
                if udp_hit.is_some() {
                    break;
                }
            }

            let tcp_targets: Vec<SocketAddr> = hosts
                .iter()
                .map(|ip| SocketAddr::new(IpAddr::V4(*ip), 443))
                .collect();
            let tcp_hit = first_answer(&tcp_targets, timeout, attempts, false).await;

            match (udp_hit, tcp_hit) {
                (Some((peer, rtt)), _) => {
                    println!("  UDP OK    {cidr}{note}  {peer} in {}ms", rtt.as_millis());
                    udp_ok.push(*cidr);
                }
                (None, Some((peer, rtt))) => {
                    println!(
                        "  TCP ONLY  {cidr}{note}  {peer} in {}ms, udp stayed silent",
                        rtt.as_millis()
                    );
                    tcp_only.push(*cidr);
                }
                (None, None) => {
                    println!("  SILENT    {cidr}{note}");
                    silent.push(*cidr);
                }
            }
        }

        println!();
        println!("masque over quic works on ({}):", udp_ok.len());
        for cidr in &udp_ok {
            println!("  {cidr}");
        }
        println!();
        println!("reachable over tcp only ({}):", tcp_only.len());
        for cidr in &tcp_only {
            println!("  {cidr}");
        }
        println!();
        println!("no answer on either ({}):", silent.len());
        for cidr in &silent {
            println!("  {cidr}");
        }

        println!();
        println!("verdict");
        if !udp_ok.is_empty() {
            println!("  put these ranges first in MASQUE_CIDRS_V4: {udp_ok:?}");
        } else if control_quic.is_none() {
            println!("  this network answers no quic at all, not even a public resolver,");
            println!("  so udp 443 is blocked here rather than these ranges being blocked.");
            println!("  reordering MASQUE_CIDRS_V4 cannot help; masque needs its http/2");
            println!("  fallback over tcp 443 (--masque-http2) on this network.");
        } else {
            println!("  quic works to other hosts but every warp range stayed silent,");
            println!("  so these ranges really are filtered here.");
            if !tcp_only.is_empty() {
                println!("  the tcp-only ranges above can still carry masque over http/2.");
            }
        }
        println!();
    }

    #[test]
    fn every_masque_prefix_and_seed_parses() {
        for entry in MASQUE_CIDRS_V4 {
            let (addr, bits) = entry.split_once('/').expect("cidr");
            assert!(addr.parse::<Ipv4Addr>().is_ok(), "{entry}");
            assert!(bits.parse::<u8>().is_ok(), "{entry}");
        }
        for entry in MASQUE_CIDRS_V6 {
            let (addr, bits) = entry.split_once('/').expect("cidr");
            assert!(addr.parse::<Ipv6Addr>().is_ok(), "{entry}");
            assert!(bits.parse::<u8>().is_ok(), "{entry}");
        }
        for seed in MASQUE_SEEDS {
            assert!(seed.parse::<Ipv4Addr>().is_ok(), "{seed}");
        }
        for seed in MASQUE_SEEDS_V6 {
            assert!(seed.parse::<Ipv6Addr>().is_ok(), "{seed}");
        }
    }

    #[tokio::test]
    async fn the_ironclad_check_offers_the_ech_key_of_its_scan() {
        let _setting = crate::upstream::hold_setting().await;
        // The check builds its TLS with the fingerprint the options give.
        let _options = crate::tls::hold_options().await;
        let identity = crate::account::handshake_identity();
        let peer = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
        let address = peer.local_addr().unwrap();
        let probe = |ech: Option<Vec<u8>>| MasqueProbe {
            sni: crate::consts::CONNECT_SNI.to_string(),
            authority: quic::default_authority().to_string(),
            path: quic::default_path().to_string(),
            cert_pem: Arc::from(identity.cert_pem.clone()),
            key_pem: Arc::from(identity.key_pem.clone()),
            ech_config_list: ech.map(Arc::from),
            noize: crate::noize::from_profile("off"),
            ports: vec![address.port()],
            ip: IpScan::V4,
            local_ipv4: Ipv4Addr::new(172, 16, 0, 2),
        };
        let timeout = Duration::from_secs(5);

        // Given a key BoringSSL offers nothing from (its one config is of another version), the
        // check sends no ClientHello; the version bait may go out before it.
        let unusable = probe(Some(vec![0, 6, 0xfe, 0x0c, 0, 2, 0, 0]));
        let checked = verify_one(&unusable, address.ip(), address.port(), timeout, true).await;
        assert!(checked.is_err());
        assert!(!quic::hears_a_client_hello(&peer, Duration::from_millis(300)).await);

        // Without a key, the same check does send one, with the server name in the clear.
        let plain = probe(None);
        let check = tokio::spawn(async move {
            verify_one(&plain, address.ip(), address.port(), timeout, true).await
        });
        assert!(quic::hears_a_client_hello(&peer, Duration::from_secs(4)).await);
        check.abort();
    }
}
